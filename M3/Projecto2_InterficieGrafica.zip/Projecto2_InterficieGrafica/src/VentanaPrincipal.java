import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class VentanaPrincipal {

	public static void main(String[] args) {
		new mainWindow();
	}

}

class mainWindow extends JFrame{
	private JPanel principalPanel, titlePanel, buttonsPanel, usernamePanel, enterPanel;
	private JLabel title;
	private JButton userB, chooseCharacter, chooseWeapon, checkRanking, fight, enterB;
	private JTextField userTF;
	private String username;
		
	
	public mainWindow() {
		this.setTitle("Ventana Principal");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setResizable(false);
		
		principalPanel = new JPanel();
		principalPanel.setLayout(new BoxLayout(principalPanel, BoxLayout.Y_AXIS));
		
		buttonsPanel = new JPanel();
		chooseCharacter = new JButton("Choose Character");
		chooseCharacter.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new chooseWindow("character");
			}
		});
		chooseWeapon = new JButton("Choose Weapon");
		chooseWeapon.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new chooseWindow("weapon");
			}
		});
		checkRanking = new JButton("Check Ranking");
		checkRanking.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		fight = new JButton("Fight");
		fight.addActionListener(new fightPanel());
		buttonsPanel.add(chooseCharacter);
		buttonsPanel.add(chooseWeapon);
		buttonsPanel.add(checkRanking);
		buttonsPanel.add(fight);
		
		
		titlePanel = new JPanel();
		title = new JLabel("PROYECTO 2 IZAN BRIAN JOEL");
		titlePanel.add(title);
		
		usernamePanel = new JPanel();
		userB = new JButton("Username");
		userB.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new enterUsernameWindow();
			}
		});
		usernamePanel.add(userB);
		
		
		
		
		
		principalPanel.add(buttonsPanel);
		principalPanel.add(titlePanel);
		principalPanel.add(usernamePanel);
		
		this.add(principalPanel);
		
		this.pack();
		this.setSize(500,350);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}
	
	class enterUsernameWindow extends JFrame {
		
		public enterUsernameWindow() {
			enterPanel = new JPanel();
			userTF = new JTextField(12);
			enterB = new JButton("Enter");
			enterB.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					username = userTF.getText();
					dispose();
				}
			});
			enterPanel.add(userTF);
			enterPanel.add(enterB);
			this.add(enterPanel);
			
			this.setTitle("Enter username");
			this.setSize(270,80);
			Toolkit pantalla = Toolkit.getDefaultToolkit();
			Dimension grandaria = pantalla.getScreenSize();
			int ancho = grandaria.width; // ancho pantalla
			int alto = grandaria.height; // alto pantalla
			this.setLocation(((ancho/2)-(this.getWidth()/2)),((alto/2)-(this.getHeight()/2))+150);
			this.setResizable(false);
			this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			this.setVisible(true);
		}
	}
	
	class chooseWindow extends JFrame {
		private JPanel choosePanel, imagePanel, statsPanel, confirmPanel;
		private JButton confirmB;
		
		public chooseWindow(String type) {
			
			imagePanel = new JPanel();
			// ***  Imagenes de los personajes/armas ***
			
			
			statsPanel = new JPanel();
			// ***  Estadisticas del personaje/arma seleccionado ***
			
			
			confirmPanel = new JPanel();
			confirmB = new JButton("Confirm");
			confirmB.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// ***  Guardar seleccion de personaje/arma  ***
					dispose();
				}
			});
			confirmPanel.add(confirmB);
			
			choosePanel = new JPanel();
			choosePanel.setLayout(new BoxLayout(choosePanel, BoxLayout.Y_AXIS));
			
			choosePanel.add(imagePanel);
			choosePanel.add(statsPanel);
			choosePanel.add(confirmPanel);
			
			this.add(choosePanel);
			
			this.setTitle("Choose "+type);
			this.setSize(500,500);
			Toolkit pantalla = Toolkit.getDefaultToolkit();
			Dimension grandaria = pantalla.getScreenSize();
			int ancho = grandaria.width; // ancho pantalla
			int alto = grandaria.height; // alto pantalla
			this.setLocation(((ancho/2)-(this.getWidth()/2))+500,((alto/2)-(this.getHeight()/2)));
			this.setResizable(false);
			this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			this.setVisible(true);
		}
	}

	class fightPanel implements ActionListener {
		private JPanel battlePanel, actionButtonsPanel, consolePanel;
		private JButton buttonFight, buttonClearConsole;
		private JTextArea console;
		
		@Override
		public void actionPerformed(ActionEvent e) {
			
			
			battlePanel = new JPanel();
			/**
			 * Barra de vida
			 * Imagen personaje y arma
			 * Stats:
			 * - poder
			 * - agilidad
			 * - velocidad
			 * - defensa
			 * 
			 * De jugador y bot
			 */
			
			actionButtonsPanel = new JPanel();
			buttonFight = new JButton("Fight");
			//buttonFight.addActionListener(   );
			buttonClearConsole = new JButton("Clear Console");
			//buttonClearConsole.addActionListener(  );
			actionButtonsPanel.add(buttonFight);
			actionButtonsPanel.add(buttonClearConsole);
			
			consolePanel = new JPanel();
			console = new JTextArea(5, 70);
			consolePanel.add(console);
			
			
			principalPanel.add(battlePanel);
			principalPanel.add(actionButtonsPanel);
			principalPanel.add(consolePanel);
			
			
			
			titlePanel.removeAll();
			usernamePanel.removeAll();
			buttonsPanel.remove(fight);
			setSize(800,700);
			setLocationRelativeTo(null);
		}
		
	}
}