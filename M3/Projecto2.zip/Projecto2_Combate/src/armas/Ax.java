package armas;

public class Ax extends Weapon{
	public Ax(String url,int id) {
		this.setUrl(url);
		this.setFuerza(3);
		this.setVelocidad(0);
		this.setId(id);
	}

}
